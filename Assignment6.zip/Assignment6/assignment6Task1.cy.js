// fixture data

// {
//     "CourseName": "Mangesh9@test.co",
//     "Description": "Mangesh9@test.co",
//     "Price": "200"
// }

// custom login commands

// Cypress.Commands.add('login', function (email, pw) {

//     cy.xpath(`//input[@id='email1']`).type(email);
//     cy.xpath(`//input[@id='password1']`).type(pw);
//     cy.xpath(`//button[@class='submit-btn']`).click(); 

// })


describe('New Course creation', function() {

    beforeEach( function() 
    {
        cy.fixture("courseData1").then(function(myData)
        {
            this.myData=myData
        })

    })

    it('Login', function() {
        
        cy.visit(`https://ineuron-courses.vercel.app`);
        cy.xpath(`//div[contains(@class,'navbar-menu-links')]//button[1]`).click();
        cy.login(`ineuron@ineuron.ai`, `ineuron`);
                       
    });

    it('Create course', function () {
        cy.contains(`Manage`).realHover();
        cy.wait(2000);
        cy.contains(`Manage Courses`).click({ force: true });
        cy.contains(`Add New Course `).click({ force: true });
        cy.xpath(`//button[@class='action-btn']`).click();
        cy.xpath(`//h2[text()='Please select a thumbnail!']`).should(`contain`,`Please select a thumbnail!`);
        cy.xpath(`//input[@id='thumbnail']`).attachFile(`dummyimage1.jpeg`);
        cy.get(`#name`).type(this.myData.CourseName);
        cy.get(`#description`).type(this.myData.Description);
        cy.get(`#instructorNameId`).type(`sw`,{delay:1000});
        cy.wait(1000);
        cy.xpath(`//div[@class='intructorsList']/p`)
        .each(function(ele)
        {
            cy.log(ele.text());
            if(ele.text().includes(`swat`))
            {
                cy.wrap(ele).click();

            }
        })
        cy.get(`#price`).type(this.myData.Price);
        cy.get(`input[name='startDate']`).click();
        cy.log (cy.xpath(`//div[@class='react-datepicker']//div[@class='react-datepicker__month']`));

        //cy.log (cy.xpath(`//div[@class='react-datepicker']//div[@aria-label='Choose Sunday, November 6th, 2022']`))
        //cy.xpath(`//div[@class='react-datepicker']//button[@aria-label='Next Month']`);
        //div[@class='react-datepicker']//button[@aria-label='Next Month']

        cy.get(`input[name='endDate']`).click();
        cy.xpath(`//div[text()='Select Category']`).click();
        cy.xpath(`//button[text()='Testing']`).click();
        cy.xpath(`//button[text()='Save']`).click();
        
    });

    it('Delete course', function()
    {
        cy.xpath(`//table//tbody//td[2]`)

        .each(function(ele1)
        {
            let arr = [cy.log(ele1.text())];
            if(ele1.text().includes(this.myData.CourseName))
            {
                cy.wrap(ele1).should(`contain`,`Mangesh9@test.co`);
            }
            cy.log(arr);
        })
        
        cy.xpath(`//table//tbody//td[text()='Mangesh9@test.co']//following::button`).click();

        
    });
});