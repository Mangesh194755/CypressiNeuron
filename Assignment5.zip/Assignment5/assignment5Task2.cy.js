describe('To Verify create new user and login', () => {
    it('Verify create new user and login', () => {
        cy.visit(`https://ineuron-courses.vercel.app`);
        cy.xpath(`//div[contains(@class,'navbar-menu-links')]//button[1]`).click();
        cy.xpath(`//a[contains(@href,'/signup')]`).should(`contain`,`New user? Signup`);
        cy.xpath(`//a[contains(@href,'/signup')]`).click();
        cy.xpath(`//button[contains(@class,'submit-btn')]`).should(`be.disabled`);
        cy.xpath(`//input[@id='name']`).type(`Mangesh`);
        cy.xpath(`//input[@id='email']`).type(`Mangesh2@test.co`);
        cy.xpath(`//input[@id='password']`).type(`test123`);
        cy.xpath(`//label[text()='Testing']//preceding::input[1]`).check();
        cy.xpath(`//input[@value='Male']`).check();
        cy.xpath(`//select[@id='state']`).select(`Goa`);
        cy.xpath(`//button[@class='submit-btn']`).click();
        cy.xpath(`//input[@id='email1']`).type(`Mangesh2@test.co`);
        cy.xpath(`//input[@id='password1']`).type(`test123`);
        cy.xpath(`//button[@class='submit-btn']`).click();
        cy.xpath(`//h4[@class='welcomeMessage']`).should(`contain`,`Welcome`);
        cy.xpath(`//button[text()='Sign out']`).should(`contain`, `Sign out`);
        cy.xpath(`//button[text()='Sign out']`).click();
        cy.xpath(`//h2[text()='Sign In']`).should(`contain`, `Sign In`);


    });
});