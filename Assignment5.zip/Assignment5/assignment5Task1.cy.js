describe('To Verify create new user and login', () => {
    it('Verify create new user and login', () => {
        cy.visit(`https://ineuron-courses.vercel.app`);
        cy.get(`.navbar-menu-links > button`).click();
        cy.get(`.subLink`).should(`contain`,`New user? Signup`);
        cy.get(`.subLink`).click();
        cy.get(`.submit-btn`).should(`be.disabled`);
        cy.get(`#name`).type(`Mangesh`);
        cy.get(`#email`).type(`Mangesh5@test.co`);
        cy.get(`#password`).type(`test123`);
        cy.get(`#63076c4329bb13ec21816100`).check();
        cy.get(`input[value*='Male']`).check();
        cy.get(`#state`).select(`Goa`);
        cy.get(`.submit-btn`).click();
    });

    it('Verify login and logout', () => {
        cy.visit(`https://ineuron-courses.vercel.app/login`);
        cy.get(`#email1`).type(`Mangesh5@test.co`);
        cy.get(`#password1`).type(`test123`);
        cy.get(`.submit-btn`).click();
        cy.wait(2000);
        cy.get(`.welcomeMessage`).should(`contain`,`Welcome`)
        cy.get(`.navbar-menu-links`).should(`contain`, `Sign out`)
        cy.get(`.navbar-menu-links > button`).click();
        cy.get(`.header`).should(`contain`, `Sign In`)

    });
});