class Courses {

    constructor(CourseName, Price, Validity, TrainerName, PhoneNumber) {
        this.CourseName = CourseName
        this.Price = Price
        this.Validity = Validity
        this.TrainerName = TrainerName
        this.PhoneNumber = PhoneNumber
    }

    showDetails() {
        console.log(`Thank you for showing interest in ${this.CourseName} - Current Price is ${this.Price}
        and validity of course is till ${this.Validity} If you have any query then
        reach out to ${this.TrainerName} mobile - ${this.PhoneNumber}`);
    }
}

let  obj1 = new Courses("English", 100, "1 year", "Mukesh", 123456)
obj1.showDetails()

let  obj2 = new Courses("Maths", 200, "1 year", "Navin", 44444)
obj2.showDetails()

let  obj3 = new Courses("Science", 300, "1 year", "Hitesh", 577546)
obj3.showDetails()