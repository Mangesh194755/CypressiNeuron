let num, sum = 0;
let i = 1;
console.log("Enter 2 numeric values to get their addition");
        
            while (i<=2){ 
                console.log("Enter a numeric value"+num);
                sum +=num;
                i++;
            }
            
            if(num=NaN){
                console.log("Please use the only number");
            }
            sum +=num;