class Courses {

    // constructor(CourseName, Price, Validity, TrainerName, PhoneNumber) {
    //     this.CourseName = CourseName
    //     this.Price = Price
    //     this.Validity = Validity
    //     this.TrainerName = TrainerName
    //     this.PhoneNumber = PhoneNumber
    // }

    get showDetails() {
        return `Thank you for showing interest in ${this.CourseName} - Current Price is ${this.Price}
        and validity of course is till ${this.Validity} If you have any query then
        reach out to ${this.TrainerName} mobile - ${this.PhoneNumber}`;
    }

    set courseName(CourseName ){
        this.CourseName = CourseName
    }
    set coursePrice(Price){ 
        this.Price = Price
    }
    set courseValidity(Validity){
        this.Validity = Validity
    }
    set courseTrainer(TrainerName){
        this.TrainerName = TrainerName
    }
    set coursePhone(PhoneNumber){
        this.PhoneNumber = PhoneNumber
    }
}

let  obj1 = new Courses()
obj1.courseName= "Maths"
obj1.coursePrice = 100
obj1.courseValidity = "1 year"
obj1.TrainerName = "Mukesh"
obj1.coursePhone = 123456

console.log(obj1.showDetails)
