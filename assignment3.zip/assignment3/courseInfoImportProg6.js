import { obj1, obj2, obj3 } from "./courseInfoExportProg6.js";


obj2.showDetails()
