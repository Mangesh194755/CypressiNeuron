describe('To Verify URL and title', () => {
    it('Verify URL and title', () => {
        cy.visit(`https://ineuron-courses.vercel.app/login`);
        cy.title().should("contain", "Courses")
        cy.url().should("contain", "login")

    });
});