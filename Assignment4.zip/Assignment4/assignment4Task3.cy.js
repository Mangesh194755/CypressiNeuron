describe('To Verify invalid logins', () => {
    it('Verify invalid logins', () => {
        cy.visit(`https://ineuron-courses.vercel.app/login`);
        // cy.get(`#email1`).type(``);
        // cy.get(`#password1`).type(``);
        cy.get(`.submit-btn`).click();
        cy.get(`.errorMessage`).should(`contain`, `Email and Password is required`)

    });
    it('Verify URL and title', () => {
        cy.visit(`https://ineuron-courses.vercel.app/login`);
        cy.get(`#email1`).type(`ineuron@ineuron.ai`);
        // cy.get(`#password1`).type(``);
        cy.get(`.submit-btn`).click();
        cy.get(`.errorMessage`).should(`contain`, `Password is required`)

    });
    it('Verify URL and title', () => {
        cy.visit(`https://ineuron-courses.vercel.app/login`);
        // cy.get(`#email1`).type(``);
        cy.get(`#password1`).type(`ineuron`);
        cy.get(`.submit-btn`).click();
        cy.get(`.errorMessage`).should(`contain`, `Email is required`)

    });
    it('Verify URL and title', () => {
        cy.visit(`https://ineuron-courses.vercel.app/login`);
        cy.get(`#email1`).type(`test@tes.co`);
        cy.get(`#password1`).type(`test`);
        cy.get(`.submit-btn`).click();
        cy.get(`.errorMessage`).should(`contain`, `USER Email Doesn't Exist`)

    });
});