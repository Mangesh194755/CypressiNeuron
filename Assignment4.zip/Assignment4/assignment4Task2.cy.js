describe('To Verify login and logout', () => {
    it('Verify login and logout', () => {
        cy.visit(`https://ineuron-courses.vercel.app/login`);
        cy.get(`#email1`).type(`ineuron@ineuron.ai`);
        cy.get(`#password1`).type(`ineuron`);
        cy.get(`.submit-btn`).click();
        cy.wait(1000);
        cy.get(`.welcomeMessage`).should(`contain`,`Welcome iNeuron to iNeuron Courses`)
        cy.get(`.navbar-menu-links`).should(`contain`, `Sign out`)
        cy.get(`.navbar-menu-links > button`).click();
        cy.get(`.header`).should(`contain`, `Sign In`)

    });
});